package com.example.quoteapp.Screens

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import com.example.quoteapp.models.Quote

@Composable
fun QuoteList(data: Array<Quote>, onClick:()->){
    LazyColumn(content = {
        items(data){
            QuoteListItem(quote = it) {
                onClick()

            }
        }
    })

}