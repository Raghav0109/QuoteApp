package com.example.quoteapp.models

class Quote (val text: String, val author:String)